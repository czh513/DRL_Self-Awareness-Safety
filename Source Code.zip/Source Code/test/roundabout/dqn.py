import datetime
import os
import sys
# Environment
import gym
import highway_env

# Agent
from stable_baselines.common.vec_env import DummyVecEnv
from stable_baselines.deepq.policies import MlpPolicy
from stable_baselines import DQN

root_folder = os.path.abspath(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.append(root_folder)

from common.testcallback import DQNCallback

env = gym.make("roundabout-v0")
# env.configure({
#     "observation": {
#         "type": "Kinematics",
#         "vehicles_count": 15,
#         "features": ["presence", "x", "y", "vx", "vy", "cos_h", "sin_h"],
#         "features_range": {
#             "x": [-100, 100],
#             "y": [-100, 100],
#             "vx": [-20, 20],
#             "vy": [-20, 20]
#         },
#         "absolute": True,
#         "order": "shuffled"
#     },
#     "duration": 13
# })

model = DQN(MlpPolicy, env, buffer_size=100000, verbose=1,
            tensorboard_log="../out1/roundabout/dqn_roundabout_tensorboard/")
model.learn(total_timesteps=int(8e6), callback=DQNCallback(60000))
model.save('dqn_mlp_roundabout_{}'.format(datetime.datetime.now().strftime('%Y%m%d-%H%M%S')))
