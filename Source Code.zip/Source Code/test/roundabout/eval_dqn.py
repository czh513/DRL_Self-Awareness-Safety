import datetime
import os
import sys
# Environment
import gym
import highway_env

# Agent
from stable_baselines.common.vec_env import DummyVecEnv
from stable_baselines.deepq.policies import MlpPolicy
from stable_baselines import DQN

root_folder = os.path.abspath(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.append(root_folder)

from common.testcallback import DQNCallback


env = gym.make("roundabout-v0")
model = DQN.load('dqn_mlp_roundabout_20210302-010402')
success_count = 0
crash_count = 0
TEST_NUM = 100
for episode in range(TEST_NUM):
    obs, done = env.reset(), False
    while not done:
        action, _ = model.predict(obs)
        obs, reward, done, info = env.step(action)
        if done:
            if info.get('is_success', False):
                success_count += 1
            if info.get('crashed', False):
                crash_count += 1
            print("Episode", episode, "Success?", info.get('is_success', False), "Crash?", info.get('crashed', False))
env.close()
print("Success Rate:", success_count/TEST_NUM)
print("Collision Rate:", crash_count/TEST_NUM)
with open('dqn_success.txt', 'a') as fd:
    fd.write(f'\n{success_count}')
with open('dqn_collision.txt', 'a') as fd:
    fd.write(f'\n{crash_count}')
