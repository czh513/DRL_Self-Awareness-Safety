import datetime
import os
import sys
import gym
# Environment
import highway_env

# Agent
from stable_baselines.common.policies import MlpPolicy
from stable_baselines.common.policies import MlpLstmPolicy
from stable_baselines import PPO2

root_folder = os.path.abspath(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.append(root_folder)

from common.testcallback import PPO2Callback

env = gym.make("intersection-v0")
env.configure({
    "observation": {
        "type": "Kinematics",
        "vehicles_count": 15,
        "features": ["presence", "x", "y", "vx", "vy", "cos_h", "sin_h"],
        "features_range": {
            "x": [-100, 100],
            "y": [-100, 100],
            "vx": [-20, 20],
            "vy": [-20, 20]
        },
        "absolute": True,
        "order": "shuffled"
    },
    "destination": "o1"
})
env.reset()

model = PPO2(MlpPolicy, env, verbose=1, learning_rate=lambda f: f * 5.0e-4, cliprange=lambda f: f * 0.1,
             tensorboard_log="../out1/intersection/ppo2_intersection_tensorboard/")
# model = PPO2(MlpLstmPolicy, env, verbose=1, learning_rate=lambda f: f * 5.0e-4, cliprange=lambda f: f * 0.1,
#              nminibatches=1, tensorboard_log="../out/intersection/ppo2_intersection_tensorboard/")

model.learn(total_timesteps=int(8e6), callback=PPO2Callback(60000))
# model.learn(total_timesteps=int(5e4))
model.save('ppo2_mlp_intersection_{}'.format(datetime.datetime.now().strftime('%Y%m%d-%H%M%S')))
