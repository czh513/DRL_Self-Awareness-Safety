from stable_baselines.common.callbacks import BaseCallback
import tensorflow as tf


class PPO2Callback(BaseCallback):
    """
    Custom callback for plotting additional values in tensorboard.
    """

    def __init__(self, episodes, verbose=0):
        self.is_tb_set = False
        self.collision_count = 0
        self.success_count = 0
        self.total_count = 0
        self.episode_length = 0
        self.rewards = []
        self.episode_limit = episodes
        super(PPO2Callback, self).__init__(verbose)

    def _on_step(self) -> bool:
        self.episode_length += 1
        self.rewards.append(self.locals.get("rewards")[0])

        info = self.locals['infos'][0]
        print(self.num_timesteps)

        # print("info?", info)

        if 'terminal_observation' in info:
            # print()
            print("total reward in episode", self.total_count,":", sum(self.rewards))
            # print()
            # self.rewards.clear()
            # print("crashed?", info.get('crashed', False))
            # print("success?", info.get('is_success', False))

            # update episode length to Tensorboard
            summary = tf.Summary(value=[tf.Summary.Value(tag='episode_length',
                                                         simple_value=self.episode_length)])
            self.locals['writer'].add_summary(summary, self.num_timesteps)
            self.episode_length = 0  # reset episode length

            self.total_count += 1
            if info.get('crashed', False):
                self.collision_count += 1
            if info.get('is_success', False):
                self.success_count += 1

            summary = tf.Summary(value=[tf.Summary.Value(tag='collision_rate',
                                                         simple_value=(self.collision_count / self.total_count))])
            self.locals['writer'].add_summary(summary, self.total_count)
            summary = tf.Summary(value=[tf.Summary.Value(tag='success_rate',
                                                         simple_value=(self.success_count / self.total_count))])
            self.locals['writer'].add_summary(summary, self.total_count)
            summary = tf.Summary(value=[tf.Summary.Value(tag='total_reward',
                                                         simple_value=(sum(self.rewards)))])
            self.locals['writer'].add_summary(summary, self.total_count)
            self.rewards.clear()

        return self.total_count < self.episode_limit


class DQNCallback(BaseCallback):
    """
    Custom callback for plotting additional values in tensorboard.
    """

    def __init__(self, episodes, verbose=0):
        self.is_tb_set = False
        self.collision_count = 0
        self.success_count = 0
        self.total_count = 0
        self.episode_length = 0
        self.episode_limit = episodes
        super(DQNCallback, self).__init__(verbose)

    def _on_step(self) -> bool:
        self.episode_length += 1
        done = self.locals['done']
        if done:
            print("total reward in episode", self.total_count,":", self.locals.get("episode_rewards")[-1])

            # update episode length to Tensorboard
            summary = tf.Summary(value=[tf.Summary.Value(tag='episode_length',
                                                         simple_value=self.episode_length)])
            self.locals['writer'].add_summary(summary, self.num_timesteps)
            self.episode_length = 0  # reset episode length

            info = self.locals['info']
            # print("crashed?", info.get('crashed', False))
            # print("success?", info.get('is_success', False))
            self.total_count += 1
            if info.get('crashed', False):
                self.collision_count += 1
            if info.get('is_success', False):
                self.success_count += 1

            summary = tf.Summary(value=[tf.Summary.Value(tag='collision_rate',
                                                         simple_value=(self.collision_count / self.total_count))])
            self.locals['writer'].add_summary(summary, self.total_count)
            summary = tf.Summary(value=[tf.Summary.Value(tag='success_rate',
                                                         simple_value=(self.success_count / self.total_count))])
            self.locals['writer'].add_summary(summary, self.total_count)
            summary = tf.Summary(value=[tf.Summary.Value(tag='total_reward',
                                                         simple_value=(self.locals.get("episode_rewards")[-1]))])
            self.locals['writer'].add_summary(summary, self.total_count)

        return self.total_count < self.episode_limit
