import numpy as np
import numpy.random as rd
import os
import logging
import torch
import torch.nn as nn
from gym import spaces

from rl_agents.agents.common.abstract import AbstractAgent
from rl_agents.agents.common.exploration.abstract import exploration_factory

logger = logging.getLogger(__name__)


class PPOAgent(AbstractAgent):

    def __init__(self, env, config=None):
        super(PPOAgent, self).__init__(config)
        self.env = env
        assert isinstance(env.action_space, spaces.Discrete), "Only compatible with Discrete action spaces."
        self.exploration_policy = exploration_factory(self.config["exploration"], self.env.action_space)
        self.training = True

        '''some default hyper-parameters put here for now'''
        self.learning_rate = 2e-4  # learning rate of actor
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.net_dim = 2 ** 7  # the network width
        self.gpu_id = 0
        self.max_memo = 2 ** 17  # memories capacity (memories: replay buffer)
        self.max_step = 2 ** 10  # max steps in one epoch
        self.reward_scale = 2 ** 0  # an approximate target reward usually be closed to 256
        self.batch_size = 2 ** 7  # num of transitions sampled from replay buffer.
        self.repeat_times = 2 ** 4  # Two-time Update Rule (TTUR)
        self.gamma = 0.99  # discount factor of future rewards

        state_dim = env.observation_space.shape[0]

        action_dim = env.action_space.n

        logger.debug("state dim {}".format(state_dim))

        '''network'''
        self.actor = ActorPPO(state_dim, action_dim, self.net_dim).to(self.device)
        self.actor.train()
        self.act_optimizer = torch.optim.Adam(self.actor.parameters(), lr=self.learning_rate, )  # betas=(0.5, 0.99))

        self.cri = CriticAdv(state_dim, self.net_dim).to(self.device)
        self.cri.train()
        self.cri_optimizer = torch.optim.Adam(self.cri.parameters(), lr=self.learning_rate, )  # betas=(0.5, 0.99))

        self.criterion = nn.SmoothL1Loss()

    @classmethod
    def default_config(cls):  # just examples of configure parameters for now
        return dict(
            learning_rate=2e-4,
            net_dim=2 ** 8,
            clip=0.25,
            lambda_adv=0.97,
            lambda_entropy=0.01,
            max_memo=2 ** 12,
            batch_size=100,
            gamma=0.99,
            repeat_times=2 ** 4,
            device="cuda:best",
            exploration=dict(method="EpsilonGreedy"),
            target_update=1,
            double=True)

    def record(self, state, action, reward, next_state, done, info):
        """
            Record a transition by performing a Deep Q-Network iteration

            - push the transition into memory
            - sample a minibatch
            - compute the bellman residual loss over the minibatch
            - perform one gradient descent step
            - slowly track the policy network with the target network
        :param state: a state
        :param action: an action
        :param reward: a reward
        :param next_state: a next state
        :param done: whether state is terminal
        """
        if not self.training:
            return

        self.actor.eval()
        self.cri.eval()

        # collect tuple (reward, mask, state, action, log_prob, )
        # PPO is an on policy RL algorithm.
        buffer = BufferTuplePPO()

        rewards = list()
        steps = list()

        step_counter = 0
        while step_counter < self.max_memo:
            # state = running_state(state)  # if state_norm:
            reward_sum = 0
            step_sum = 0

            for step_sum in range(self.max_step):
                action, log_prob = self.select_actions((state,), explore_noise=True)
                action = action[0]
                log_prob = log_prob[0]

                # next_state, reward, done, _ = env.step(action * max_action)
                reward_sum += reward

                # next_state = running_state(next_state)  # if state_norm:
                mask = 0.0 if done else self.gamma

                reward_ = reward * self.reward_scale
                buffer.push(reward_, mask, state, action, log_prob, )

                if done:
                    break

                state = next_state

            rewards.append(reward_sum)
            steps.append(step_sum)

            step_counter += step_sum

            #  invoke this method here temporarily
            # self.update_parameters_online(buffer, self.batch_size, self.repeat_times)

        return rewards, steps, buffer

    def update_parameters_online(self, buffer, batch_size, repeat_times):
        self.actor.train()
        self.cri.train()
        clip = 0.25  # ratio.clamp(1 - clip, 1 + clip)
        lambda_adv = 0.97  # why 0.97? cannot seem to use 0.99
        lambda_entropy = 0.01
        # repeat_times = 8

        loss_a_sum = 0.0
        loss_c_sum = 0.0

        '''the batch for training'''
        max_memo = len(buffer)
        all_batch = buffer.sample()
        all_reward, all_mask, all_state, all_action, all_log_prob = [
            torch.tensor(ary, dtype=torch.float32, device=self.device)
            for ary in (all_batch.reward, all_batch.mask, all_batch.state, all_batch.action, all_batch.log_prob,)
        ]
        # with torch.no_grad():
        all_new_value = self.cri(all_state).detach_()

        '''compute old_v (old policy value), adv_v (advantage value) 
        refer: Generalization Advantage Estimate. ICLR 2016. 
        https://arxiv.org/pdf/1506.02438.pdf'''
        all_delta = torch.empty(max_memo, dtype=torch.float32, device=self.device)
        all_old_v = torch.empty(max_memo, dtype=torch.float32, device=self.device)  # old policy value
        all_adv_v = torch.empty(max_memo, dtype=torch.float32, device=self.device)  # advantage value

        prev_old_value = 0
        prev_new_value = 0
        prev_advantage = 0
        for i in range(max_memo - 1, -1, -1):
            all_delta[i] = all_reward[i] + all_mask[i] * prev_new_value - all_new_value[i]
            all_old_v[i] = all_reward[i] + all_mask[i] * prev_old_value
            all_adv_v[i] = all_delta[i] + all_mask[i] * prev_advantage * lambda_adv

            prev_old_value = all_old_v[i]
            prev_new_value = all_new_value[i]
            prev_advantage = all_adv_v[i]

        all_adv_v = (all_adv_v - all_adv_v.mean()) / (all_adv_v.std() + 1e-6)  # if advantage_norm:

        '''mini batch sample'''

        sample_times = int(repeat_times * max_memo / batch_size)
        for i_epoch in range(sample_times):
            # random sample
            indices = rd.choice(max_memo, batch_size, replace=True)  # False)

            state = all_state[indices]
            a_noise = all_action[indices]
            advantage = all_adv_v[indices]
            old_value = all_old_v[indices].unsqueeze(1)
            old_log_prob = all_log_prob[indices]

            """Adaptive KL Penalty Coefficient
            loss_KLPEN = surrogate_obj + value_obj * lambda_value + entropy_obj * lambda_entropy
            loss_KLPEN = (value_obj * lambda_value) + (surrogate_obj + entropy_obj * lambda_entropy)
            loss_KLPEN = (critic_loss) + (actor_loss)
            """

            '''critic_loss'''
            new_log_prob = self.actor.compute__log_prob(state, a_noise)

            new_value = self.cri(state)
            critic_loss = self.criterion(new_value, old_value) / (old_value.std() + 1e-6)
            loss_c_sum += critic_loss.item()
            self.cri_optimizer.zero_grad()
            critic_loss.backward()
            self.cri_optimizer.step()

            '''actor_loss'''
            # surrogate objective of TRPO
            ratio = torch.exp(new_log_prob - old_log_prob)
            surrogate_obj0 = advantage * ratio
            surrogate_obj1 = advantage * ratio.clamp(1 - clip, 1 + clip)
            surrogate_obj = -torch.mean(torch.min(surrogate_obj0, surrogate_obj1))
            # policy entropy
            loss_entropy = torch.mean(torch.exp(new_log_prob) * new_log_prob)

            actor_loss = surrogate_obj + lambda_entropy * loss_entropy
            loss_a_sum += actor_loss.item()
            self.act_optimizer.zero_grad()
            actor_loss.backward()
            self.act_optimizer.step()

        loss_a_avg = loss_a_sum / sample_times
        loss_c_avg = loss_c_sum / sample_times
        return loss_a_avg, loss_c_avg

    def act(self, state):
        """
            Act according to the state-action value model and an exploration policy
        :param state: current state
        :return: an action
        """
        action, _ = self.select_actions((state,), explore_noise=True)
        return action[0]
        # return self.env.action_space.sample()

    def seed(self, seed=None):
        return self.exploration_policy.seed(seed)

    def reset(self):
        pass

    def set_writer(self, writer):
        super().set_writer(writer)
        try:
            self.exploration_policy.set_writer(writer)
        except AttributeError:
            pass

    def set_time(self, time):
        self.exploration_policy.set_time(time)

    def eval(self):
        self.training = False
        self.config['exploration']['method'] = "Greedy"
        self.exploration_policy = exploration_factory(self.config["exploration"], self.env.action_space)

    def save(self, filename):
        act_save_path = '{}/actor.pth'.format(filename)
        cri_save_path = '{}/critic.pth'.format(filename)
        has_cri = 'cri' in dir(self)
        torch.save(self.actor.state_dict(), act_save_path)
        torch.save(self.cri.state_dict(), cri_save_path) if has_cri else None

    def load(self, filename):

        def load_torch_file(network, save_path):
            network_dict = torch.load(save_path, map_location=lambda storage, loc: storage)
            network.load_state_dict(network_dict)

        act_save_path = '{}/actor.pth'.format(filename)
        cri_save_path = '{}/critic.pth'.format(filename)
        has_cri = 'cri' in dir(self)
        if os.path.exists(act_save_path):
            load_torch_file(self.actor, act_save_path)
            load_torch_file(self.cri, cri_save_path) if has_cri else None

    def select_actions(self, states, explore_noise=0.0):  # CPU array to GPU tensor to CPU array
        states = torch.tensor(states, dtype=torch.float32, device=self.device)

        if explore_noise == 0.0:
            a_mean = self.actor(states)
            a_mean = a_mean.cpu().data.numpy()
            return a_mean
        else:
            a_noise, log_prob = self.actor.get__a__log_prob(states)
            a_noise = a_noise.cpu().data.numpy()
            log_prob = log_prob.cpu().data.numpy()
            return a_noise, log_prob


class BufferTuplePPO:
    def __init__(self, ):
        self.storage_list = list()
        from collections import namedtuple
        self.transition = namedtuple(
            'Transition',
            # ('state', 'value', 'action', 'log_prob', 'mask', 'next_state', 'reward')
            ('reward', 'mask', 'state', 'action', 'log_prob')
        )

    def push(self, *args):
        self.storage_list.append(self.transition(*args))

    def extend(self, storage_list):
        self.storage_list.extend(storage_list)

    def sample(self):
        return self.transition(*zip(*self.storage_list))

    def __len__(self):
        return len(self.storage_list)


class ActorPPO(nn.Module):
    def __init__(self, state_dim, action_dim, mid_dim):
        super(ActorPPO, self).__init__()

        self.net__mean = nn.Sequential(nn.Linear(state_dim, mid_dim), nn.ReLU(),
                                       nn.Linear(mid_dim, mid_dim), nn.ReLU(),
                                       nn.Linear(mid_dim, action_dim), )
        self.net__std_log = nn.Parameter(torch.zeros(1, action_dim), requires_grad=True)
        self.constant_log_sqrt_2pi = np.log(np.sqrt(2 * np.pi))

        layer_norm(self.net__mean[0], std=1.0)
        layer_norm(self.net__mean[2], std=1.0)
        layer_norm(self.net__mean[4], std=0.01)  # output layer for action

    def forward(self, s):
        a_mean = self.net__mean(s)
        return a_mean.tanh()

    def get__a__log_prob(self, state):
        a_mean = self.net__mean(state)
        a_log_std = self.net__std_log.expand_as(a_mean)
        a_std = torch.exp(a_log_std)
        a_noise = torch.normal(a_mean, a_std)

        a_delta = (a_noise - a_mean).pow(2) / (2 * a_std.pow(2))
        log_prob = -(a_delta + a_log_std + self.constant_log_sqrt_2pi)
        log_prob = log_prob.sum(1)
        return a_noise, log_prob

    def compute__log_prob(self, state, a_noise):
        a_mean = self.net__mean(state)
        a_log_std = self.net__std_log.expand_as(a_mean)
        a_std = torch.exp(a_log_std)

        a_delta = (a_noise - a_mean).pow(2) / (2 * a_std.pow(2))
        log_prob = -(a_delta + a_log_std + self.constant_log_sqrt_2pi)
        return log_prob.sum(1)


class CriticAdv(nn.Module):  # 2020-05-05 fix bug
    def __init__(self, state_dim, mid_dim):
        super(CriticAdv, self).__init__()

        self.net = nn.Sequential(nn.Linear(state_dim, mid_dim), nn.ReLU(),
                                 nn.Linear(mid_dim, mid_dim), nn.ReLU(),
                                 nn.Linear(mid_dim, 1), )

        layer_norm(self.net[0], std=1.0)
        layer_norm(self.net[2], std=1.0)
        layer_norm(self.net[4], std=1.0)  # output layer for action

    def forward(self, s):
        q = self.net(s)
        return q


def layer_norm(layer, std=1.0, bias_const=1e-6):
    torch.nn.init.orthogonal_(layer.weight, std)
    torch.nn.init.constant_(layer.bias, bias_const)
