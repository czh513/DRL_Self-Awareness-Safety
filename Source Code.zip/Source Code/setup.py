from setuptools import setup, find_packages

setup(
    name='TestHighway',
    version='1.0.dev0',
    description='Test different algorithms on highway-env',
    author='Jie Yun',
    author_email='jie.yun2014@gmail.com',
    license='MIT',
    keywords='highway env RL algorithms',
    packages=find_packages(exclude=['docs', 'scripts', 'tests*']),
    install_requires=['highway-env', 'stable-baselines'],
)

