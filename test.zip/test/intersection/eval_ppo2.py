import datetime
import os
import sys
import gym
# Environment
import highway_env

# Agent
from stable_baselines.common.policies import MlpPolicy
from stable_baselines.common.policies import MlpLstmPolicy
from stable_baselines import PPO2

root_folder = os.path.abspath(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.append(root_folder)

from common.testcallback import PPO2Callback

env = gym.make("intersection-v0")

model = PPO2.load('ppo2_mlp_intersection_20200907-002514')
success_count = 0
crash_count = 0
TEST_NUM = 100
for episode in range(TEST_NUM):
    obs, done = env.reset(), False
    while not done:
        action, _ = model.predict(obs)
        obs, reward, done, info = env.step(action)
        if done:
            if info.get('is_success', False):
                success_count += 1
            if info.get('crashed', False):
                crash_count += 1
            print("Episode", episode, "Success?", info.get('is_success', False), "Crash?", info.get('crashed', False))
env.close()
print("Success Rate:", success_count/TEST_NUM)
print("Collision Rate:", crash_count/TEST_NUM)

with open('ppo_success.txt', 'a') as fd:
    fd.write(f'\n{success_count}')
with open('ppo_collision.txt', 'a') as fd:
    fd.write(f'\n{crash_count}')


