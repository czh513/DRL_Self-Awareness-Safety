import datetime
import os
import sys
# Environment
import gym
import highway_env

# Agent
from stable_baselines.common.policies import MlpPolicy
from stable_baselines.common import make_vec_env
from stable_baselines import A2C

root_folder = os.path.abspath(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.append(root_folder)

from common.testcallback import PPO2Callback

# Parallel environments
env = make_vec_env('intersection-v0', n_envs=4)
# env.configure({
#     "observation": {
#         "type": "Kinematics",
#         "vehicles_count": 15,
#         "features": ["presence", "x", "y", "vx", "vy", "cos_h", "sin_h"],
#         "features_range": {
#             "x": [-100, 100],
#             "y": [-100, 100],
#             "vx": [-20, 20],
#             "vy": [-20, 20]
#         },
#         "absolute": True,
#         "order": "shuffled"
#     },
#     "destination": "o1"
# })
model = A2C(MlpPolicy, env, verbose=1, tensorboard_log="../out1/intersection/a2c_intersection_tensorboard/")
model.learn(total_timesteps=int(8e6), callback=PPO2Callback(60000))
model.save('a2c_mlp_intersection_{}'.format(datetime.datetime.now().strftime('%Y%m%d-%H%M%S')))