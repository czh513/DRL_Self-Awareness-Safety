import datetime
import os
import sys
# Environment
import gym
import highway_env

# Agent
from stable_baselines.common.policies import MlpPolicy
from stable_baselines.common import make_vec_env
from stable_baselines import A2C

for i in range(100):
    exec(open("eval_a2c.py").read())
# for i in range(100):
#     exec(open("eval_dqn.py").read())
