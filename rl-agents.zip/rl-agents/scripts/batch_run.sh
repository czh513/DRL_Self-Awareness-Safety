#! /bin/sh
for i in {1..80}; do
#python experiments.py evaluate configs/IntersectionEnv/env.json configs/IntersectionEnv/agents/DQNAgent/ego_attention_2h.json --test --episodes=2 --recover-from out/IntersectionEnv/DQNAgent/run_20200917-135359_52148/checkpoint-best.tar --no-display;
python experiments.py evaluate configs/IntersectionEnv/env.json configs/IntersectionEnv/agents/DQNAgent/ego_attention_2h.json --test --episodes=100 --recover-from /Users/yunjie/Downloads/experiment_layernorm_intersection/run_20210504-193828_20080/checkpoint-best.tar --no-display;
done

#for i in {1..20}; do
#python experiments.py evaluate configs/IntersectionEnv/env.json configs/IntersectionEnv/agents/DQNAgent/ego_attention_2h.json --test --episodes=100 --recover-from /Users/yunjie/Downloads/experiment_layernorm_intersection/run_20210504-195707_72845/checkpoint-best.tar --no-display;
#python experiments.py evaluate configs/IntersectionEnv/env.json configs/IntersectionEnv/agents/DQNAgent/ego_attention_2h.json --test --episodes=100 --recover-from /Users/yunjie/Downloads/experiment_layernorm_intersection/run_20210504-195921_77725/checkpoint-best.tar --no-display;
#python experiments.py evaluate configs/IntersectionEnv/env.json configs/IntersectionEnv/agents/DQNAgent/ego_attention_2h.json --test --episodes=100 --recover-from /Users/yunjie/Downloads/experiment_layernorm_intersection/run_20210506-001558_103114/checkpoint-best.tar --no-display;
#python experiments.py evaluate configs/IntersectionEnv/env.json configs/IntersectionEnv/agents/DQNAgent/ego_attention_2h.json --test --episodes=100 --recover-from /Users/yunjie/Downloads/experiment_layernorm_intersection/run_20210506-001806_106088/checkpoint-best.tar --no-display;
#done

#for i in {1..20}; do
##python experiments.py evaluate configs/IntersectionEnv/env.json configs/IntersectionEnv/agents/DQNAgent/ego_attention_2h.json --test --episodes=2 --recover-from out/IntersectionEnv/DQNAgent/run_20200917-135359_52148/checkpoint-best.tar --no-display;
#python experiments.py evaluate configs/IntersectionEnv/env.json configs/IntersectionEnv/agents/DQNAgent/ego_attention_2h.json --test --episodes=100 --recover-from /Users/yunjie/Downloads/experiment_layernorm_intersection/run_20210504-195921_77725/checkpoint-best.tar --no-display;
#done
#
#for i in {1..20}; do
##python experiments.py evaluate configs/IntersectionEnv/env.json configs/IntersectionEnv/agents/DQNAgent/ego_attention_2h.json --test --episodes=2 --recover-from out/IntersectionEnv/DQNAgent/run_20200917-135359_52148/checkpoint-best.tar --no-display;
#python experiments.py evaluate configs/IntersectionEnv/env.json configs/IntersectionEnv/agents/DQNAgent/ego_attention_2h.json --test --episodes=100 --recover-from /Users/yunjie/Downloads/experiment_layernorm_intersection/run_20210506-001558_103114/checkpoint-best.tar --no-display;
#done
#
#for i in {1..20}; do
##python experiments.py evaluate configs/IntersectionEnv/env.json configs/IntersectionEnv/agents/DQNAgent/ego_attention_2h.json --test --episodes=2 --recover-from out/IntersectionEnv/DQNAgent/run_20200917-135359_52148/checkpoint-best.tar --no-display;
#python experiments.py evaluate configs/IntersectionEnv/env.json configs/IntersectionEnv/agents/DQNAgent/ego_attention_2h.json --test --episodes=100 --recover-from /Users/yunjie/Downloads/experiment_layernorm_intersection/run_20210506-001806_106088/checkpoint-best.tar --no-display;
#done



